﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;

namespace Comp2139_Lab1.Models
{
    public class Project
    {
        [Required]

         public int ProjectId {  get; set; }
         public required string Name { get; set; } 
         public string? Description { get; set; }//here Description is optional field so we have given it question mark? and resambles as nullable..

        [DataType(DataType.Date)]
        public DateTime StartDate {  get; set; }

        [DataType(DataType.Date)]
         public DateTime EndDate { get; set; }

         public string? Status { get; set; }
         
    }
}
