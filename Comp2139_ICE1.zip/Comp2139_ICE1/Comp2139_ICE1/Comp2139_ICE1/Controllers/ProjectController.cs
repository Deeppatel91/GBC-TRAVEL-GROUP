﻿using Comp2139_Lab1.Models;
using Microsoft.AspNetCore.Mvc;

namespace Comp2139_Lab1.Controllers
{
    public class ProjectController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            var projects = new List<Project>()
            {
                new Project { ProjectId = 1, Name= "Project 1 ",Description="First Project" },


                new Project { ProjectId = 2, Name= "Project 2 ",Description="Second Project" },

         
                new Project { ProjectId = 3, Name= "Project 3 ",Description="Third Project" }




            };


            return View(projects);

        }



        [HttpGet]
        public IActionResult Details(int id)
        {

            var project = new Project { ProjectId = id, Name= "Project" + id, Description= "Details of project" + id };
            return View();

        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Create(Project project)
        {
            return RedirectToAction("Index");
        }





    }
    
}
